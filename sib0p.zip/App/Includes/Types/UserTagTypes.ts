declare namespace UserTagTypes {
	export interface Tag {
		id: number
		icon: string
		name: string
		color: string
	}
}

export default UserTagTypes
