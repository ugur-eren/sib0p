import LightTheme from  './LightTheme'
import DarkTheme from './DarkTheme'

export default {
    light: LightTheme,
    dark: DarkTheme
}