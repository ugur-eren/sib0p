import { StyleSheet } from 'react-native'

export default StyleSheet.create({
	logoContainer: {
		flex: 1,
		paddingVertical: 12,
	},
	logo: {
		flex: 1,
	},
})
