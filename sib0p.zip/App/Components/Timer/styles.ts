import { StyleSheet } from 'react-native'

export default StyleSheet.create({
	container: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	icon: {
		marginRight: 5,
	},
})
