import { StyleSheet } from 'react-native'
import Config from '../../Includes/Config'

export default StyleSheet.create({
	itemSeperator: {
		width: '100%',
		marginVertical: 10,
	},
})
